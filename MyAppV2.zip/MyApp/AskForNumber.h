/*
* This function gets an int from user and checks that is an int
*/
#include <stdio.h>

int getNum()
{
	int favNumber = 21; //used for return value, is at 21 to use for a checker
	do  //while favNumber is unchanged at 21 do
	{
		int gotIt;
		printf("Choose a number from 1-20: \n");  //request from user a number
		scanf_s("%d", &gotIt);  //save the number to gotIt
		for (int i = 0; i <= 3; i++)  //loop to check user response, if i reaches three = bad news
		{
			
			if (gotIt <= 20)  //if gotIt is less than or equal to 20
			{
				favNumber = gotIt;  //favNumber is now the value of gotIt, breaking the do/while loop
				break;
			}
			else if (i == 3)  //else if i is the same as 3
			{
				printf("Sorry");  //apologize to user
				return 1; //exit code
			}
			else  //else try again
			{
				printf("Please only choose a number from 1-20! \n");
				break;
			}
			
		}
	} while (favNumber == 21);
	printf("The test equals = %i\n", favNumber);
	return favNumber;
}
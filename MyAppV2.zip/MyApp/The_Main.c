/*
* This program requests info from user and then transforms that info into a memorable password
* that is somewhat secure
*/

#include <string.h>
#include "AskForNumber.h"
#include "StructAndSalt.h"
#include "RemoveWarning.h"
#include "Animals.h"

int main()
{
	struct Passwords Password1;  //create struct of type password
	char word[26];  //char array
	word[25] = 0;
	printf("Input one word you find easily remembered; \n"); //ask for user input
	scanf_s("%s", word, sizeof(word) -1);  //save user input to char array
	int theNum = getNum();  //call function getNum and save value to theNum
	char thisAnimal = getAnimal(theNum);  //call getAnimal function using theNum as animal to choose
	Password1.partOne = MY_SALT; //create first part of password as MY_SALT
	Password1.partTwo; //create memory for second part
	Password1.partThree = theNum; //create third part using user input
	Password1.lastPart; //create memory for last part
	for (int i = 0; i < 26; i++)  //for loop to run through every char in array
	{
		Password1.partTwo[i] = word[i];  //use each char from word as second part of password

		Password1.lastPart[i] = neededValue;  //use each char from dataRead as last part of password
	}
	printf("Your password is: \n");  //the next six lines display the password and then ends main
	printf("%i", Password1.partOne);
	printf("%s", Password1.partTwo);
	printf("%i", Password1.partThree);
	printf("%s", Password1.lastPart);
	return 0;
}


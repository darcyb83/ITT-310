#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char dataRead[500] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz,"; //this is a char array holding name of animal
char neededValue;

int getAnimal(int theNum) // this function picks an animal name from a file based on length of user input
{
	int a = 0, b = 0;  //place holders
	char copy = 'a';
	FILE* file = fopen("Animals.txt", "r");  //open the file
	if (file == NULL)  //if the file is null
	{
		printf("ERROR!! The file Animals.txt was not found \n"); //print this
		EXIT_FAILURE;
	}
	else
	{
		file = fopen("Animals.txt", "r");
		neededValue = fgetc(file);  //read file char by char
		copy = neededValue;
		//fclose(file);
	}
	int neededCommas = theNum;
	char neededBuffer[500] = { copy };
	char theAnimal[] = { "ABCDEabcdefghijklmnopqrstuvwxyz" };
	int  c = 0, d = 0, e = 0; 
	for (int i = 0; i < neededCommas; i++)
	{
		c = i;
		if (c == theNum - 1)
		{
			d = c;
		}	
		else if (c == theNum)
		{
			e = c;
			i = neededCommas;
			break;
		}
	}
	int f = 0;
	int t = c;
	for (int i = 0; i < 32; i++)
	{
		theAnimal[f] = neededBuffer[t];
		neededValue = theAnimal[f];
		f++;
		t++;
		e++;
		if (t == e - 1)
		{
			i = 98;
			break;
		}
	}
	printf("test theAnimal = %c\n", theAnimal[31]);
	return (int)theAnimal;
}